package com.mayank.notilizer2.ui;

import android.content.Intent;

import com.mayank.notilizer2.NotificationAppView;
import com.mayank.notilizer2.NotificationDateView;

import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

public class HistoryWeeklyFragment extends HistoryFragment {
    protected SimpleDateFormat dateFormat = new SimpleDateFormat("w");

    @Override
    protected void startAppDetailActivity(String appName, Date date) {
        Intent intent = new Intent(getActivity(), AppDetail.class);
        intent.putExtra(AppDetail.EXTRA_PACKAGENAME, appName);
        intent.putExtra(AppDetail.EXTRA_INTERVALTYPE, AppDetail.FLAG_VIEW_WEEKLY);
        intent.putExtra(AppDetail.EXTRA_DATESTRING, new SimpleDateFormat("yyyy-MM-dd").format(date));
        startActivity(intent);
    }

    @Override
    protected List<NotificationDateView> getChartData(int items) throws SQLException {
        List<NotificationDateView> notificationDateViews = this.getDatabaseHelper().getNotificationDao().getSummaryLastWeeks(items);
        //add weeks without notifications to finalData list
        List<NotificationDateView> completeNotificationDateViews = new ArrayList<NotificationDateView>();
        for (int i = 0; i < notificationDateViews.size(); i++) {
            completeNotificationDateViews.add(completeNotificationDateViews.size(), notificationDateViews.get(i));
            if (i < notificationDateViews.size() - 1) {
                Calendar nextNotificationDate = Calendar.getInstance();
                nextNotificationDate.setTime(notificationDateViews.get(i + 1).Date);
                nextNotificationDate.set(Calendar.HOUR_OF_DAY, 0);
                nextNotificationDate.set(Calendar.MINUTE, 0);
                nextNotificationDate.set(Calendar.SECOND, 0);
                nextNotificationDate.set(Calendar.MILLISECOND, 0);

                Calendar nextCalendarDate = Calendar.getInstance();
                nextCalendarDate.setTime(notificationDateViews.get(i).Date);
                nextCalendarDate.add(Calendar.WEEK_OF_YEAR, 1);
                nextCalendarDate.set(Calendar.HOUR_OF_DAY, 0);
                nextCalendarDate.set(Calendar.MINUTE, 0);
                nextCalendarDate.set(Calendar.SECOND, 0);
                nextCalendarDate.set(Calendar.MILLISECOND, 0);

                while (nextCalendarDate.get(Calendar.WEEK_OF_YEAR) != nextNotificationDate.get(Calendar.WEEK_OF_YEAR)){
                    NotificationDateView emptyEntry = new NotificationDateView();
                    emptyEntry.Date = nextCalendarDate.getTime();
                    completeNotificationDateViews.add(completeNotificationDateViews.size(), emptyEntry);
                    nextCalendarDate.add(Calendar.WEEK_OF_YEAR, 1);
                }
            }
        }

        return completeNotificationDateViews;

    }

    @Override
    protected List<NotificationAppView> getListViewDate(Date date) throws SQLException {
        return this.getDatabaseHelper().getNotificationDao().getOverviewWeek(date);
    }

    /**
     * Gets the SimpleDateFormat used for formatting the labels on the chart.
     *
     * @return the correct SimpleDateFormat.
     */
    @Override
    protected SimpleDateFormat getDateFormat() {
        return dateFormat;
    }
}
